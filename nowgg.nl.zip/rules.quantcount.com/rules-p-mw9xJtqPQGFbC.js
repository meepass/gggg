/*
 Quantcast measurement tag
 Copyright (c) 2008-2022, Quantcast Corp.
*/
'use strict';(function(a,b,c){__qc("rules",[a])})("p-mw9xJtqPQGFbC",window,document);